package library_management;

import javax.swing.JLabel;

public class AlertMessage {
	public AlertMessage ( final String message, JLabel label ) {
		label = new JLabel(message);
		
	}
}
