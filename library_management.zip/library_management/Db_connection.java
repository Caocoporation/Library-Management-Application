package library_management;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Db_connection {
	public static ArrayList<String> getUserData (String username) {
		java.sql.Connection connection;
		
		ArrayList<String> userData = new ArrayList<String>();
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from users where username = '" + username + "'";
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				while (rs.next()) {
					userData.add(rs.getString(1));
					userData.add(rs.getString(2));
					userData.add(rs.getString(3));
					userData.add(rs.getString(4));
				}
			}
			
			connection.close();
			
			return userData;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userData;
	}
	
	public static int retrieve_users (String username) {
		java.sql.Connection connection;
		int count = 0;
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from users where username = '" + username + "'";
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				while (rs.next()) {
					count += 1;
				}
			}
			
			connection.close();
			
			return count;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}
	
	public static ArrayList<String> getBookData (String title) {
		java.sql.Connection connection;
		
		ArrayList<String> bookData = new ArrayList<String>();
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from books where title = '" + title + "'";
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				System.out.println("True");
				while (rs.next()) {
					System.out.println(rs.getString(2));
					bookData.add(rs.getString(2));
					bookData.add(rs.getString(3));
					bookData.add(rs.getString(4));
					bookData.add(rs.getString(5));
					bookData.add(rs.getString(6));
				}
			}
			
			connection.close();
			
			return bookData;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookData;
	}
	
	public static void insert_users (String username, String password, String address) {
		java.sql.Connection connection;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
		
			String insert_query = "insert into users (username, password, address) " + 
					"values('" + username + "', '" + password + "', '" + address + "')";
			
			java.sql.Statement statement = connection.createStatement();
			
			int is_success = statement.executeUpdate(insert_query);
			System.out.println(is_success);
			
			if ( is_success == 0 ) {
				System.out.println("Fail!");
			} 
			
			else {
				System.out.println("Success !");
			}
			
			connection.close();
			
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void update_books (String bookTitle, String status) {
		java.sql.Connection connection;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
		
			String insert_query = "update books set status = " + status 
					+ " where title = '" + bookTitle + "'";
			
			java.sql.Statement statement = connection.createStatement();
			
			int is_success = statement.executeUpdate(insert_query);
			System.out.println(is_success);
			
			if ( is_success == 0 ) {
				System.out.println("Fail!");
			} 
			
			else {
				System.out.println("Success !");
			}
			
			connection.close();
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void insert_borrowings (String userId, String isbn, String returned) {
		java.sql.Connection connection;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
		
			String insert_query = "insert into borrowings (isbn, user_id, returned) " + 
					"values('" + isbn + "', '" + userId + "', '" + returned + "' )";
			
			java.sql.Statement statement = connection.createStatement();
			
			int is_success = statement.executeUpdate(insert_query);
			System.out.println(is_success);
			
			if ( is_success == 0 ) {
				System.out.println("Fail!");
			} 
			
			else {
				System.out.println("Success !");
			}
			
			connection.close();
			
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static int checkBorrowings (String userId, String bookISBN) {
		java.sql.Connection connection;
		
		int count = 0;
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from borrowings where user_id = " 
			+ userId + " and isbn = '" 
			+ bookISBN + "'";
			
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				while (rs.next()) {
					count += 1;
				}
			}
			
			connection.close();
			
			return count;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}
	
	public static ArrayList<String> all_book () {
		java.sql.Connection connection;
		
		ArrayList<String> book_titles = new ArrayList<String>();
		
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from books";
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				while (rs.next()) {
					book_titles.add(rs.getString(2));
				}
			}
			
			connection.close();
			
			return book_titles;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return book_titles;
	}
	
	public static int find_book (String bookId) {
		java.sql.Connection connection;
		int count = 0;
		
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
			
			String retrieve_query = "select * from books where id = '" + bookId + "'";
			java.sql.Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(retrieve_query);
			
			if (rs != null) {
				while (rs.next()) {
					count += 1;
				}
			}
			
			connection.close();
			
			return count;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}
	
	public static void insert_books (String title, String author, String publisher, String isbn, String status) {
		java.sql.Connection connection;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/cao_library",
					"root",
					""
			);
		
			String insert_query = "insert into books (title, author, isbn, status, publisher) " + 
					"values('" + title + "', '" 
					+ author + "', '" 
					+ isbn + "', '" 
					+ status + "', '" 
					+ publisher + "' )";
			
			java.sql.Statement statement = connection.createStatement();
			
			int is_success = statement.executeUpdate(insert_query);
			System.out.println(is_success);
			
			if ( is_success == 0 ) {
				System.out.println("Fail!");
			} 
			
			else {
				System.out.println("Success !");
			}
			
			connection.close();	
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
