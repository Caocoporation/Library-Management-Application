/**
 * 
 */
package library_management;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author MY PC
 *
 */
public class Login_window extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static JPanel loginPanel;
	private static JLabel loginTitle;
	private static JTextField username;
	private static JPasswordField pwd, con_pwd;
	private static JButton login_btn;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		loginPanel = new JPanel();
		loginTitle = new JLabel();
		int setStartingPoint = (600 / 2) - (150 / 2);
		loginTitle.setBounds(setStartingPoint, 20, 150, 35);
		
	}

}
