package library_management;

import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;


public class Generate_Element {
	public static JLabel set_label (JLabel label, String message, int[] comp_bound) {
		label = new JLabel(message);
		label.setBounds(
			comp_bound[0], 
			comp_bound[1], 
			comp_bound[2], 
			comp_bound[3]
		);
		
		return label;
	}
	
	public static JTextField set_text_field (JTextField textFieldName, int[] comp_bound, int[] padding  ) {
		textFieldName = new JTextField();
		textFieldName.setBounds(
			comp_bound[0], 
			comp_bound[1], 
			comp_bound[2], 
			comp_bound[3]
		);
		
		textFieldName.setBorder(BorderFactory.createEmptyBorder(
				padding[0],
				padding[1],
				padding[2],
				padding[3]
			)
		);	
		
		return textFieldName;
	}
	
	public static JPasswordField set_password_field (JPasswordField passwordFieldName, int[] comp_bound, int[] padding  ) {
		passwordFieldName = new JPasswordField();
		passwordFieldName.setBounds(
			comp_bound[0], 
			comp_bound[1], 
			comp_bound[2], 
			comp_bound[3]
		);
		
		passwordFieldName.setBorder(BorderFactory.createEmptyBorder(
				padding[0],
				padding[1],
				padding[2],
				padding[3]
			)
		);	
		
		return passwordFieldName;
	}
	
	public static JButton set_button (JButton button_name, String btn_title, int[] comp_bound, int[] padding) {
		button_name = new JButton(btn_title);
		button_name.setBounds(
			comp_bound[0], 
			comp_bound[1], 
			comp_bound[2], 
			comp_bound[3]
		);
		
		button_name.setBorder(BorderFactory.createEmptyBorder(
				padding[0],
				padding[1],
				padding[2],
				padding[3]
			)
		);
		
		return button_name;
	}
}
