/**
 * 
 */
package library_management;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * @author MY PC
 *
 */
public class Register_window implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int ComboBoxModel = 0;
	public static JFrame reg_frame = new JFrame();
	public static JPanel con_panel = new JPanel();
	public static JPanel view_panel;
	public static JPanel reg_panel;
	public static JPanel log_panel;
	public static JPanel addb_panel;
	public static JPanel bookb_panel;
	
	private static JLabel title_panel, username_label, pwd_label, con_pwd_label, alertMessage, addressLB;
	private static JTextField username;
	private static JPasswordField pwd, con_pwd;
	private static JButton registerBtn, signUpBtn, signInBtn, logoutBtn, addBtn, backBtn, borrowBtn, returnBtn;
	private static CardLayout cardLayout = new CardLayout();
	
	// JLabel 
	private static JLabel addBookBT, addBookBA, addBookBP, addBookBI, addBookBS, addBookTitle;
	private static JLabel addBookBT_2, addBookBA_2, addBookBP_2, addBookBI_2, addBookBS_2, addBookTitle_2;
	
	// Text Field
	private static JTextField addBookBTF, addBookBAF, addBookBPF, addBookBIF, addBookBSF;
	
	// Registration Form
	private static JTextField usernameTF, addressTF;
	private static JPasswordField passwordPF, conPasswordPF;
	
	// Dropdown menu
	
	private static JComboBox<String> dropDownBook;
	
	// Dummy storage
	private static String userId = null;
	private static String getUsername = null;
	
	/**
	 * @param args
	 */
	public static double[] middle_vertical (double get_size, double wid_obj, double height_obj, double y ) {
		double x = (get_size / 2) - (wid_obj / 2);
		double get_coor[] = {x, y, wid_obj, height_obj};
		return get_coor; 
	}
	
	public static JPanel viewBookPanel () {
		view_panel = new JPanel();
		view_panel.setBackground(Color.orange);
		view_panel.setLayout(null);
		
		System.out.println(userId);
		
		int[] ptitle_bound = {120, 20, 100, 30};
		addBookTitle = Generate_Element.set_label(addBookTitle, "Borrow Book", ptitle_bound);
		
		ArrayList<String> all_books = Db_connection.all_book();
		
		int[] bTBound = {120, 105, 100, 30};
		addBookBT = Generate_Element.set_label(addBookBT, "Title", bTBound);
		
		int[] bABound = {120, 140, 100, 30};
		addBookBA = Generate_Element.set_label(addBookBA, "Author", bABound);
		
		int[] bPBound = {120, 175, 100, 30};
		addBookBP = Generate_Element.set_label(addBookBP, "Publisher", bPBound);
		
		int[] bIBound = {120, 210, 100, 30};
		addBookBI = Generate_Element.set_label(addBookBI, "ISBN", bIBound);
		
		int[] bSBound = {120, 240, 100, 30};
		addBookBS = Generate_Element.set_label(addBookBS, "Status", bSBound);
		
		// -------------------------------------------------------------------
		
		int[] bTBound2 = {240, 105, 150, 30};
		addBookBT_2 = Generate_Element.set_label(addBookBT_2, "....", bTBound2);
		
		int[] bABound2 = {240, 140, 150, 30};
		addBookBA_2 = Generate_Element.set_label(addBookBA_2, "....", bABound2);
		
		int[] bPBound2 = {240, 175, 150, 30};
		addBookBP_2 = Generate_Element.set_label(addBookBP_2, "....", bPBound2);
		
		int[] bIBound2 = {240, 210, 150, 30};
		addBookBI_2 = Generate_Element.set_label(addBookBI_2, "....", bIBound2);
		
		int[] bSBound2 = {240, 240, 150, 30};
		addBookBS_2 = Generate_Element.set_label(addBookBS_2, "....", bSBound2);
		
		// Button
		int[] bBBound = {120, 285, 100, 35};
		int[] bBPadding = {0, 0, 0, 0};
		borrowBtn = Generate_Element.set_button(borrowBtn, "Borrow", bBBound, bBPadding);
		view_panel.add(borrowBtn);
		
		int[] bBBound2 = {225, 285, 100, 35};
		int[] bBPadding2 = {0, 0, 0, 0};
		returnBtn = Generate_Element.set_button(returnBtn, "Return", bBBound2, bBPadding2);
		view_panel.add(returnBtn);
		
		int[] bBBound3 = {120, 325, 100, 35};
		int[] bBPadding3 = {0, 0, 0, 0};
		logoutBtn = Generate_Element.set_button(logoutBtn, "Logout", bBBound3, bBPadding3);
		view_panel.add(logoutBtn);
		
		int[] bBBound4 = {225, 325, 100, 35};
		int[] bBPadding4 = {0, 0, 0, 0};
		addBtn = Generate_Element.set_button(addBtn, "Add Book", bBBound4, bBPadding4);
		view_panel.add(addBtn);
		
		
		view_panel.add(addBookBT_2);
		view_panel.add(addBookBA_2);
		view_panel.add(addBookBP_2);
		view_panel.add(addBookBI_2);
		view_panel.add(addBookBS_2);
		
		
		
		dropDownBook = new JComboBox<String>(all_books.toArray(new String[all_books.size()]));
		dropDownBook.setBounds(120, 65, 150, 35);
		dropDownBook.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String getBookTitle = (String) dropDownBook.getSelectedItem();
				ArrayList<String> bookData = Db_connection.getBookData(getBookTitle);
				
				if (! bookData.isEmpty()) {
					addBookBT_2.setText(bookData.get(0));
					addBookBA_2.setText(bookData.get(1));
					addBookBP_2.setText(bookData.get(4));
					addBookBI_2.setText(bookData.get(2));
					
					if (bookData.get(3).equalsIgnoreCase("1")) {
						addBookBS_2.setText("Available");
					}
					
					else {
						addBookBS_2.setText("Unavailable");
					}
				}
			}
		});
		
		addBtn.addActionListener(new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ArrayList<String> user = Db_connection.getUserData(getUsername);
				
				if (! user.isEmpty() ) {
					System.out.println("That's true");
					System.out.println(user.get(3));
					if ( user.get(3).equalsIgnoreCase("1") ) {
						cardLayout.show(con_panel, "3");
					}
					
					else {
						int[] alertBound = {120, 375, 250, 30};
						alertMessage = Generate_Element.set_label(alertMessage, "", alertBound);
						view_panel.add(alertMessage);
						alertMessage.setText("You are not allowed to add more book.");
					}
				}
				
				Timer timer = new Timer(3000, new ActionListener() {
					  @Override
					  public void actionPerformed(ActionEvent arg0) {
						  alertMessage.setText("");
					  }
				});
				
				timer.setRepeats(false); 
				timer.start(); 
			}	
		}); 
		
		
		logoutBtn.addActionListener(new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cardLayout.show(con_panel, "1");
			}
		});
		
		
		borrowBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				// Alert Message
				int[] alertBound = {120, 375, 250, 30};
				alertMessage = Generate_Element.set_label(alertMessage, "", alertBound);
				view_panel.add(alertMessage);
				
				String bookStatus = null;
				
				if ( addBookBS_2.getText().toString().equalsIgnoreCase("Available") ) {
					System.out.println("True");
					bookStatus = "0";
					Db_connection.insert_borrowings(userId, addBookBI_2.getText().toString(), bookStatus);
					Db_connection.update_books(addBookBT_2.getText().toString(), bookStatus);
					alertMessage.setText("You have borrowed the book.");
					addBookBS_2.setText("Unavailable");
				} 
				
				else {
					alertMessage.setText("The book has been borrowed.");
				}
				
				Timer timer = new Timer(3000, new ActionListener() {
					  @Override
					  public void actionPerformed(ActionEvent arg0) {
						  alertMessage.setText("");
					  }
				});
				
				timer.setRepeats(false); 
				timer.start(); 
			};	
		});
		
		returnBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				int[] alertBound = {120, 375, 300, 30};
				alertMessage = Generate_Element.set_label(alertMessage, "", alertBound);
				view_panel.add(alertMessage);
				
				String bookStatus = null;
				
				if (Db_connection.checkBorrowings(userId, addBookBI_2.getText().toString()) != 0) {
					bookStatus = "1";
					Db_connection.update_books(addBookBT_2.getText().toString(), bookStatus);
					alertMessage.setText("The book has been returned. Thank you!!!");
					addBookBS_2.setText("Available");
				}
				
				else {
					alertMessage.setText("The book has been borrowed by someone else.");
				}
				
				Timer timer = new Timer(3000, new ActionListener() {
					  @Override
					  public void actionPerformed(ActionEvent arg0) {
						  alertMessage.setText("");
					  }
				});
				
				timer.setRepeats(false); 
				timer.start(); 
			}
		});
		
	
		view_panel.add(dropDownBook);
		view_panel.add(addBookTitle);
		view_panel.add(addBookBT);
		view_panel.add(addBookBA);
		view_panel.add(addBookBP);
		view_panel.add(addBookBI);
		view_panel.add(addBookBS);
		
		
		return view_panel;
	}
	
	// Add book
	public static JPanel addBookPanel () {
		addb_panel = new JPanel();
		addb_panel.setBackground(Color.orange);
		addb_panel.setLayout(null);
		
		// Set font 
		
		// Set label
		int[] ptitle_bound = {(600 / 2 - 100 / 2), 20, 100, 30};
		addBookTitle = Generate_Element.set_label(addBookTitle, "Add New Book", ptitle_bound);
		
		int[] bTBound = {120, 65, 100, 30};
		addBookBT = Generate_Element.set_label(addBookBT, "Book Title", bTBound);
		
		int[] bABound = {120, 100, 100, 30};
		addBookBA = Generate_Element.set_label(addBookBA, "Book Author", bABound);
		
		int[] bPBound = {120, 135, 100, 30};
		addBookBP = Generate_Element.set_label(addBookBP, "Book Publisher", bPBound);
		
		int[] bIBound = {120, 170, 100, 30};
		addBookBI = Generate_Element.set_label(addBookBI, "Book ISBN", bIBound);
		
		int[] bSBound = {120, 205, 100, 30};
		addBookBS = Generate_Element.set_label(addBookBS, "Book Status", bSBound);
		
		// Set text fields
		
		int[] padding = {0, 5, 0, 0};
		int[] bTFBound = {250, 65, 200, 30};
		addBookBTF = Generate_Element.set_text_field(addBookBTF, bTFBound, padding);
		
		int[] bAFBound = {250, 100, 200, 30};
		addBookBAF = Generate_Element.set_text_field(addBookBAF, bAFBound, padding);
		
		int[] bPFBound = {250, 135, 200, 30};
		addBookBPF = Generate_Element.set_text_field(addBookBPF, bPFBound, padding);
		
		int[] bIFBound = {250, 170, 200, 30};
		addBookBIF = Generate_Element.set_text_field(addBookBIF, bIFBound, padding);
		
		int[] bSFBound = {250, 205, 200, 30};
		addBookBSF = Generate_Element.set_text_field(addBookBSF, bSFBound, padding);
		
		// Set button
		
		int[] bBBound = {120, 255, 100, 30};
		addBtn = Generate_Element.set_button(addBtn, "Add", bBBound, padding);
		
		int[] bBBound_2 = {250, 255, 100, 30};
		backBtn = Generate_Element.set_button(backBtn, "Back to View", bBBound_2, padding);
		
		addb_panel.add(addBookTitle);
		addb_panel.add(addBookBT);
		addb_panel.add(addBookBA);
		addb_panel.add(addBookBP);
		addb_panel.add(addBookBI);
		addb_panel.add(addBookBS);
		
		addb_panel.add(addBookBTF);
		addb_panel.add(addBookBAF);
		addb_panel.add(addBookBPF);
		addb_panel.add(addBookBIF);
		addb_panel.add(addBookBSF);
		
		addb_panel.add(addBtn);
		addb_panel.add(backBtn);
		
		
		backBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cardLayout.show(con_panel, "4");
			}
		});
		
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String title = addBookBTF.getText().toString();
				String author = addBookBAF.getText().toString();
				String publisher = addBookBPF.getText().toString();
				String isbn = addBookBIF.getText().toString();
				String status = addBookBSF.getText().toString();
				
				int[] alertBound = {120, 320, 150, 30};
				alertMessage = Generate_Element.set_label(alertMessage, " ", alertBound);
				addb_panel.add(alertMessage);
				
				String[] check_field = { title, author, publisher, isbn, status };
				
				System.out.println(String.valueOf(check_field.length));
				System.out.println(String.valueOf(title.length()));
				
				boolean flag = true;
				
				
				for (int i = 0; i < check_field.length; i++) {
					
					if ( check_field[i].length() == 0 ) {
						flag = false;
					}
				}
				
				if ( flag ) {
					if ( Db_connection.find_book(title) != 0 ) {
						alertMessage.setText("The book has exised in the library.");
					}
					
					else {
						Db_connection.insert_books(title, author, publisher, isbn, status);
						alertMessage.setText("The book has been added successfully.");
					}	
				} 
				
				else {
					alertMessage.setText("You must fill in the form.");
				}
				
					
				Timer timer = new Timer(3000, new ActionListener() {
					  @Override
					  public void actionPerformed(ActionEvent arg0) {
						  alertMessage.setText("");
					  }
				});
				
				timer.setRepeats(false); 
				timer.start(); 
			}
		});
		
		return addb_panel;
	}
	
	public static JPanel loginPanel () {
		log_panel = new JPanel();
		log_panel.setBackground(Color.orange);
		log_panel.setLayout(null);
		
		// Set alert message
		alertMessage = new JLabel(" ");
		alertMessage.setBounds(50, 250, 300, 35);		
		log_panel.add(alertMessage);
		
		// Set title panel
		title_panel = new JLabel("Login to Cao Library");
		title_panel.setBounds((600 / 2 - 250 / 2), 20, 250, 35);
		title_panel.setFont(new Font ("Serif", Font.BOLD, 20));
		log_panel.add(title_panel);
		
		// Set username field
		username_label = new JLabel("Username");
		username_label.setBounds(150, 65, 100, 35);		
		log_panel.add(username_label);
		
		int[] username_bound = {270, 65, 150, 30};
		int[] username_padding = {0, 5, 0, 0};
		username = Generate_Element.set_text_field(username, username_bound, username_padding);
		log_panel.add(username);
		
		// Set password field
		pwd_label = new JLabel("Password");
		pwd_label.setBounds(150, 105, 100, 35);
		log_panel.add(pwd_label);
		
		int[] pwd_bound = {270, 105, 150, 30};
		int[] pwd_padding = {0, 5, 0, 0};
		
		pwd = Generate_Element.set_password_field(pwd, pwd_bound, pwd_padding);
		log_panel.add(pwd);
		
		
		// Sign-in btn
		int[] signInBound = {150, 200, 100, 30};
		int[] signInPadding = {0, 5, 0, 0};
		
		signInBtn = Generate_Element.set_button(signInBtn, "Sign In", signInBound, signInPadding);
		log_panel.add(signInBtn);
		
		signInBtn.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Hello !");			
				System.out.println(username.getText().toString());
				ArrayList<String> user = new ArrayList<String>();
				user = Db_connection.getUserData(username.getText().toString());
				
				if (user.isEmpty()) {
					System.out.println("Username or Password is invalid !");
					
				}
				
				else {
					if (user.get(2).equalsIgnoreCase(pwd.getText().toString())) {
						System.out.println("Login successfully !");
						userId = user.get(0);
						getUsername = user.get(1);
						cardLayout.show(con_panel, "4");
					}
					
					else {
						System.out.println("Fail !");
						alertMessage.setText("Fail !!!");
						ToastMessage toastMsg = new ToastMessage("Fail !!!", log_panel);
						toastMsg.display();
					}
				}
			}		
		});
		
		// Sign-up btn
		int[] signUpBound = {350, 200, 100, 30};
		int[] signUpPadding = {0, 5, 0, 0};
		
		signUpBtn = Generate_Element.set_button(signUpBtn, "Sign Up", signUpBound, signUpPadding);
		log_panel.add(signUpBtn);
		
		signUpBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cardLayout.show(con_panel, "2");
			}
			
		});
		
		return log_panel;
	}
	
	public static JPanel registerPanel () {
		reg_panel = new JPanel();
		
		// set up panel 
		reg_panel.setBackground(Color.orange);
		reg_panel.setLayout(null);
		
		// set up labels
		title_panel = new JLabel("Registration Form");
		username_label = new JLabel("Username");
		pwd_label = new JLabel("Password");
		con_pwd_label = new JLabel("Conf-Password");
		
		double[] get_coor = middle_vertical(600, 200, 35, 10);
		title_panel.setBounds( (int) get_coor[0], (int) get_coor[1], (int) get_coor[2], (int) get_coor[3]);
		title_panel.setFont(new Font ("Serif", Font.BOLD, 20));
		reg_panel.add(title_panel);
		
		// username 
		username_label.setBounds(150, 65, 100, 35);		
		reg_panel.add(username_label);
				
		int[] username_bound = {270, 65, 150, 30};
		int[] username_padding = {0, 5, 0, 0};
		usernameTF = Generate_Element.set_text_field(usernameTF, username_bound, username_padding);
		reg_panel.add(usernameTF);
		
		// password
		pwd_label.setBounds(150, 105, 100, 35);
		reg_panel.add(pwd_label);
		
		int[] pwd_bound = {270, 105, 150, 30};
		int[] pwd_padding = {0, 5, 0, 0};
		
		passwordPF = Generate_Element.set_password_field(passwordPF, pwd_bound, pwd_padding);
		reg_panel.add(passwordPF);
		
		// confirm password
		con_pwd_label.setBounds(150, 145, 100, 35);
		reg_panel.add(con_pwd_label);
		
		int[] con_pwd_bound = {270, 145, 150, 30};
		int[] con_pwd_padding = {0, 5, 0, 0};
		
		conPasswordPF = Generate_Element.set_password_field(conPasswordPF, con_pwd_bound, con_pwd_padding);
		reg_panel.add(conPasswordPF);
		
		// address 
		int[] addressBound = {150, 185, 150, 30};
		int[] addressPadding = {0, 5, 0, 0};
		
		addressLB = Generate_Element.set_label(addressLB, "Address", addressBound);	
		reg_panel.add(addressLB);
				
		int[] addressTFBound = {270, 185, 150, 30};

		addressTF = Generate_Element.set_text_field(addressTF, addressTFBound, addressPadding);
		reg_panel.add(addressTF);
		
		
		// register button
		
		int[] reg_btn_bound = {290, 235, 100, 30};
		int[] reg_btn_padding = {0, 5, 0, 0};
		
		registerBtn = Generate_Element.set_button(registerBtn, "Register", reg_btn_bound, reg_btn_padding);
		reg_panel.add(registerBtn);
		
		int[] back_btn_bound = {150, 235, 100, 30};
		int[] back_btn_padding = {0, 0, 0, 0};
		
		backBtn = Generate_Element.set_button(backBtn, "Login", back_btn_bound, back_btn_padding);
		reg_panel.add(backBtn);
		
		backBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cardLayout.show(con_panel, "1");
			}
		});
		
		registerBtn.addActionListener(new ActionListener() {

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				String con_pwd_text = conPasswordPF.getText().toString();
				String pwd_text = passwordPF.getText().toString();
				String username_text = usernameTF.getText().toString();
				String address_text = addressTF.getText().toString();
				
				// alert message
				int[] alertBound = {150, 285, 250, 30};
				alertMessage = Generate_Element.set_label(alertMessage, " ", alertBound);
				reg_panel.add(alertMessage);
				
				System.out.println(address_text);
				
				String[] listCheck = {username_text, pwd_text, con_pwd_text, address_text};
				
				boolean valid = true;
				
				for (int i = 0; i < listCheck.length; i++) {
					System.out.println(listCheck[i]);
					if ( listCheck[i].isEmpty() ) {
						valid = false;
						break;
					}
				}
			
				if (valid) {
					System.out.println("---- is working !!!");
					if ( Db_connection.retrieve_users(username_text) != 0 ) {
						alertMessage.setText("");
						alertMessage.setText("The username has existed.");
					}
					
					else {
						if (con_pwd_text.equalsIgnoreCase(pwd_text) && (pwd_text.length() >= 8)) {
							try {
								Db_connection.insert_users(username_text, pwd_text, address_text);
								cardLayout.show(con_panel, "1");
							}
								
							catch (Exception e1) {
								e1.printStackTrace();
							}
						}
						
						else {
							alertMessage.setText("");
							alertMessage.setText("Confirmed password has to be the same to password.");
						}
					}	
				}
				
				else {
					System.out.println("-- is working !!!");
					alertMessage.setText("");
					alertMessage.setText("Please fill in all of the fields first.");
				}
			}
		});
		
		return reg_panel;
	}
	
	public Register_window() {
		con_panel.setLayout(cardLayout);
		
		con_panel.add(viewBookPanel(), "4");
		con_panel.add(addBookPanel(), "3");
		con_panel.add(registerPanel(), "2");
		con_panel.add(loginPanel(), "1");
		
		cardLayout.show(con_panel, "1");
		
		
		// button events
		
		// frame setup
		reg_frame.add(con_panel);
		reg_frame.setSize(600, 600);
		reg_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		reg_frame.setVisible(true);
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				new Register_window();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
